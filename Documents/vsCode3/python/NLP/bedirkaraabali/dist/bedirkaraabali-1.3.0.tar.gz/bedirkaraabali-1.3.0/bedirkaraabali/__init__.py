from . import print_name

print_name('bedir')